import { prisma } from "@/configuracion/Prisma";
import { secureQuery } from "@/helpers/secureQuery";
import type { Request, Response } from "express"
import { Router } from "express";

const api: Router = Router()

api.get("/", async (req: Request, res: Response) => {
    const { limit, offset, order, full } = secureQuery(req)

    const AHORA = new Date()
    const HOY = new Date(AHORA.getFullYear(), AHORA.getMonth(), AHORA.getDate())

    try {

        const [ausencias, count] = await prisma.$transaction([

            // Obtener todas las ausencias que no se vencieron
            prisma.ausencia.findMany({
                // El filtro se aplica si no viene full=true
                where: full ? {} : { fecha: { gte: HOY } },

                // La paginacion se aplica solo si viene
                ...(limit !== undefined && { take: limit }),
                ...(offset !== undefined && { skip: offset }),

                // ordenar por lo que estan mas cerca
                orderBy: {
                    createdAt: order ?? "desc",
                },
            }),

            // contar todas las ausencias
            prisma.ausencia.count({
                where: full ? {} : { fecha: { gte: HOY } }
            })
        ])


        

    } catch (err) {
        console.error("Error al obtener eventos:", err)
        return res.status(500).json({
            message: "ErrorServidor",
            data: null,
            meta: {},
        })
    }
})

export { api as AusenciasRoute }
